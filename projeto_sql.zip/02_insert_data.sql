INSERT INTO cliente (nome, email, telefone) VALUES
('Ana Souza', 'ana@gmail.com', '1197777-1111'),
('Bruno Lima', 'bruno@gmail.com', '1198888-2222'),
('Carla Mendes', 'carla@gmail.com', '1199999-3333');

INSERT INTO produto (nome, preco, categoria) VALUES
('Notebook Dell', 4200.00, 'Informática'),
('Teclado Mecânico', 350.00, 'Informática'),
('Mesa Escritório', 799.90, 'Móveis');

INSERT INTO pedido (id_cliente, data_pedido) VALUES
(1, '2024-03-01'),
(2, '2024-03-02');

INSERT INTO item_pedido (id_pedido, id_produto, quantidade, subtotal) VALUES
(1, 1, 1, 4200.00),
(1, 2, 1, 350.00),
(2, 3, 1, 799.90);
