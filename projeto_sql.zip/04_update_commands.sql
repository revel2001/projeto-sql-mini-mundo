UPDATE cliente
SET email = 'ana.souza@empresa.com'
WHERE id_cliente = 1;

UPDATE produto
SET preco = preco * 1.15
WHERE categoria = 'Informática';

UPDATE item_pedido
SET quantidade = 2, subtotal = 700.00
WHERE id_item = 2;
