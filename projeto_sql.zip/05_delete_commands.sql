DELETE FROM item_pedido WHERE id_item = 3;

DELETE FROM cliente WHERE id_cliente = 3;

DELETE FROM produto WHERE id_produto = 2;
