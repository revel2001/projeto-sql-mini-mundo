# Projeto SQL – Mini-mundo
Scripts SQL organizados para criação, inserção, consulta, atualização e remoção de dados.
