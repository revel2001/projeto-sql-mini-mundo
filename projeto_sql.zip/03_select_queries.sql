SELECT * FROM cliente ORDER BY nome ASC;

SELECT nome, preco FROM produto WHERE preco > 500;

SELECT p.id_pedido, c.nome, p.data_pedido
FROM pedido p
JOIN cliente c ON p.id_cliente = c.id_cliente;

SELECT ip.id_item, pr.nome, ip.quantidade, ip.subtotal
FROM item_pedido ip
JOIN produto pr ON ip.id_produto = pr.id_produto
WHERE ip.id_pedido = 1;

SELECT * FROM produto ORDER BY preco DESC LIMIT 2;
